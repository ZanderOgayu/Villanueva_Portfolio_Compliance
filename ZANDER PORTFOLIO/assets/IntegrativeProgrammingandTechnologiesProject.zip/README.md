# Predicting Coffee Shop Sales Using Machine Learning
**Coffeemotto Coffee Shop | IPT 101 TP#4**
*Pamantasan ng Lungsod ng Valenzuela (AY 2025–2026)*
*Group: Rivera, Villanueva, Salario, Francisco*

This project contains a machine learning pipeline that predicts transaction-level sales for Coffeemotto Coffee Shop using a trained Random Forest Regressor. It includes an interactive HTML5 Dashboard and a FastAPI backend.

---

## 🛠️ Requirements & Setup on Another Computer

To run this project on any other computer (Windows/macOS/Linux), follow these step-by-step instructions.

### 1. Install Python
The new computer must have Python installed:
* Download and install the latest version of Python from [python.org](https://www.python.org/downloads/).
* **CRITICAL DURING INSTALLATION:** On the installer screen, make sure to check the box that says **"Add Python.exe to PATH"** (or **"Add Python to environment variables"**). If you miss this, you won't be able to run Python commands from the terminal.

---

### 2. Copy the Project Folder
Copy the entire project folder (`IntegrativeProgrammingandTechnologiesProject`) to the other computer (via a USB drive, Google Drive, GitHub, etc.).

---

### 3. Open the Folder in VS Code
1. Open **VS Code** on the other computer.
2. Click **File** > **Open Folder** and select the copied `IntegrativeProgrammingandTechnologiesProject` folder.
3. Open a terminal inside VS Code: Go to **Terminal** > **New Terminal** at the top menu.

---

### 4. Install Project Dependencies
Run the following command in the terminal to install all required libraries:
```bash
pip install -r requirements.txt
```
*Note: If `pip` is not recognized, try `python -m pip install -r requirements.txt`.*

---

### 5. Train the Model (Generate .pkl Files)
The machine learning models need to be generated on the machine before running the server. Run this command:
```bash
python train.py
```
Wait for the script to finish. It will create several `.pkl` files (such as `random_forest_model.pkl`, `scaler.pkl`, etc.) and some `.png` charts in the project folder.

---

### 6. Run the FastAPI Server
To launch the backend API server that calculates predictions:
```bash
python app.py
```
Keep this terminal running. You should see a message saying the server is running on `http://127.0.0.1:8000`.

---

### 7. Open the HTML Dashboard
After training the model and starting the server, you need to open the user interface:
1. Open Windows File Explorer and navigate to the project folder.
2. Double-click **`coffeemotto_ml_dashboard.html`** to open it in any web browser (Chrome, Edge, Firefox).
3. Alternatively, in VS Code:
   * Right-click `coffeemotto_ml_dashboard.html` in the explorer panel and select **Open in Default Browser** (or **Reveal in File Explorer** and double-click it).
   * Or if you have the **Live Server** extension, click **Go Live** at the bottom-right corner of VS Code.
4. Go to the **ML Predictor** tab on the page and verify that the API status dot is green (**"API Connected"**).

---

## 🚦 How to Turn the FastAPI Server (Uvicorn) OFF and ON

The backend server must be running whenever you want to make predictions on the dashboard.

### To Turn the Server OFF:
1. Go to the VS Code terminal window where the server (`python app.py`) is running.
2. Click inside the terminal and press **`Ctrl + C`** on your keyboard.
3. If prompted with `Terminate batch job (Y/N)?`, type **`Y`** and press **Enter**.
4. The server will stop, and you will see the normal command line prompt reappear. Predictions on the HTML dashboard will now show a connection error.

### To Turn the Server ON again:
1. In the same terminal window, make sure you are in the project folder.
2. Run the start command again:
   ```bash
   python app.py
   ```
3. Once the output shows `Uvicorn running on http://127.0.0.1:8000`, the server is online and the dashboard is ready to make predictions again.

