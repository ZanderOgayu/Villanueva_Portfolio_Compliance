# =============================================================================
# Coffeemotto Coffee Shop — Sales Prediction ML Pipeline
# IPT 101 TP#4 | Pamantasan ng Lungsod ng Valenzuela
# Group: Rivera, Villanueva, Salario, Francisco
# =============================================================================

# --- SECTION 1: IMPORTS & LOAD DATA ---
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import warnings
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from sklearn.model_selection import train_test_split, KFold, cross_val_score, GridSearchCV
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

warnings.filterwarnings('ignore')

# ----- Load Both Datasets -----
print("=" * 65)
print("  COFFEEMOTTO COFFEE SHOP — ML SALES PREDICTION PIPELINE")
print("=" * 65)

print("\n[1] Loading datasets...")

# Load transactions (primary ML dataset)
transactions = pd.read_csv("Coffee Motto Datasets/transactions.csv")
print(f"\n📄 transactions.csv loaded: {transactions.shape[0]} rows × {transactions.shape[1]} columns")
print(transactions.head(3).to_string())

# Load daily summary (EDA visualizations)
daily = pd.read_csv("Coffee Motto Datasets/daily_summary.csv")
print(f"\n📄 daily_summary.csv loaded: {daily.shape[0]} rows × {daily.shape[1]} columns")
print(daily.head(3).to_string())


# --- SECTION 2: DATA PREPROCESSING ---
print("\n" + "=" * 65)
print("[2] Data Preprocessing")
print("=" * 65)

df = transactions.copy()

# Drop non-informative transaction_id
df.drop(columns=['transaction_id'], inplace=True)
print("\n✓ Dropped 'transaction_id' column.")

# Parse date, extract month and week_of_year
df['date'] = pd.to_datetime(df['date'])
df['month'] = df['date'].dt.month
df['week_of_year'] = df['date'].dt.isocalendar().week.astype(int)
print("✓ Extracted 'month' and 'week_of_year' from date.")

# Drop original date and day_of_week string columns
df.drop(columns=['date', 'day_of_week'], inplace=True)
print("✓ Dropped 'date' and 'day_of_week' (string) columns.")

# Label-encode categorical string columns
le_product = LabelEncoder()
le_category = LabelEncoder()

df['product_encoded'] = le_product.fit_transform(df['product_name'])
df['category_encoded'] = le_category.fit_transform(df['category'])

# Store encoder mappings for use in the HTML predictor / FastAPI backend
product_mapping = dict(zip(le_product.classes_, le_product.transform(le_product.classes_)))
category_mapping = dict(zip(le_category.classes_, le_category.transform(le_category.classes_)))

print(f"\n✓ Label-encoded 'product_name' → {len(le_product.classes_)} unique products.")
print(f"✓ Label-encoded 'category' → {len(le_category.classes_)} unique categories.")
print(f"\n  Category mapping: {category_mapping}")

# Drop original string columns (we keep the encoded versions)
df.drop(columns=['product_name', 'category'], inplace=True)

# Define feature matrix X and target y
FEATURE_COLS = ['day_num', 'is_weekend', 'hour', 'category_encoded',
                'product_encoded', 'unit_price', 'quantity', 'month', 'week_of_year']

X = df[FEATURE_COLS]
y = df['gross_sales']

print(f"\n✓ Feature matrix X shape: {X.shape}")
print(f"✓ Target vector y shape: {y.shape}")
print(f"\nFeature columns: {FEATURE_COLS}")

# Apply MinMaxScaler to features
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)
X_scaled = pd.DataFrame(X_scaled, columns=FEATURE_COLS)
print("\n✓ Applied MinMaxScaler to all features.")

# 80/20 Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.20, random_state=42
)
print(f"\n✓ Train set: {X_train.shape[0]} samples | Test set: {X_test.shape[0]} samples (80/20 split)")


# --- SECTION 3: EXPLORATORY DATA ANALYSIS (EDA) ---
print("\n" + "=" * 65)
print("[3] Exploratory Data Analysis")
print("=" * 65)

# --- Summary statistics of gross_sales ---
gs = transactions['gross_sales']
print("\n📊 Gross Sales Summary Statistics (transactions.csv):")
print(f"  Mean:   ₱{gs.mean():.2f}")
print(f"  Median: ₱{gs.median():.2f}")
print(f"  Std:    ₱{gs.std():.2f}")
print(f"  Min:    ₱{gs.min():.2f}")
print(f"  Max:    ₱{gs.max():.2f}")

# --- Top 5 products by total gross_sales ---
top5 = transactions.groupby('product_name')['gross_sales'].sum().sort_values(ascending=False).head(5)
print("\n🏆 Top 5 Products by Total Gross Sales:")
for rank, (prod, sales) in enumerate(top5.items(), 1):
    print(f"  {rank}. {prod}: ₱{sales:,.0f}")

# --- Sales by category (sorted descending) ---
cat_sales = transactions.groupby('category')['gross_sales'].sum().sort_values(ascending=False)
print("\n📂 Gross Sales by Category (Top 10):")
for i, (cat, sales) in enumerate(cat_sales.head(10).items(), 1):
    print(f"  {i:2d}. {cat:25s} ₱{sales:>8,.0f}")

# ─── Consistent warm color palette ───
ESPRESSO  = '#1C0A00'
MOCHA     = '#6B4226'
LATTE     = '#C8A882'
CREAM     = '#FDF6EC'
FOAM      = '#F5E6D3'
GREEN     = '#4A7C59'
GOLD      = '#C9A84C'
WARM_PALETTE = [ESPRESSO, MOCHA, LATTE, FOAM, GREEN, GOLD,
                '#8B5E3C', '#A0785A', '#D4B896', '#5C8A6A']

# Chart 1 — Daily Gross Sales Trend (all 60 days from daily_summary.csv)
print("\n📈 Saving EDA Chart 1: Daily Sales Trend...")
daily['date'] = pd.to_datetime(daily['date'])
daily = daily.dropna(subset=['date', 'gross_sales'])

fig, ax = plt.subplots(figsize=(14, 5))
ax.set_facecolor(CREAM)
fig.patch.set_facecolor('#FAF0E6')

# Shade weekends
for _, row in daily.iterrows():
    if row['is_weekend'] == 1:
        ax.axvspan(row['date'] - pd.Timedelta(hours=12),
                   row['date'] + pd.Timedelta(hours=12),
                   alpha=0.15, color=MOCHA, zorder=0)

ax.plot(daily['date'], daily['gross_sales'],
        color=MOCHA, linewidth=2.5, marker='o', markersize=5,
        markerfacecolor=GOLD, markeredgecolor=ESPRESSO, markeredgewidth=0.8, zorder=3)
ax.fill_between(daily['date'], daily['gross_sales'], alpha=0.15, color=MOCHA)

ax.set_title('Daily Gross Sales Trend — Coffeemotto Coffee Shop\n(Mar 6 – May 4, 2026 | Shaded = Weekend)',
             fontsize=13, fontweight='bold', color=ESPRESSO, pad=12)
ax.set_xlabel('Date', fontsize=11, color=MOCHA)
ax.set_ylabel('Gross Sales (₱)', fontsize=11, color=MOCHA)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'₱{x:,.0f}'))
ax.grid(True, linestyle='--', alpha=0.4, color=MOCHA)
ax.tick_params(colors=ESPRESSO)
plt.xticks(rotation=45, ha='right', fontsize=8)
plt.tight_layout()
plt.savefig('eda_sales_trend.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Saved eda_sales_trend.png")

# Chart 2 — Top 5 Products Horizontal Bar Chart
print("📊 Saving EDA Chart 2: Top 5 Products...")
top5_sorted = top5.sort_values(ascending=True)
fig, ax = plt.subplots(figsize=(10, 5))
ax.set_facecolor(CREAM)
fig.patch.set_facecolor('#FAF0E6')

colors = [ESPRESSO, MOCHA, '#8B5E3C', LATTE, GOLD]
bars = ax.barh(top5_sorted.index, top5_sorted.values,
               color=colors[::-1], edgecolor=ESPRESSO, linewidth=0.6)
for bar, val in zip(bars, top5_sorted.values):
    ax.text(bar.get_width() + 40, bar.get_y() + bar.get_height() / 2,
            f'₱{val:,.0f}', va='center', fontsize=10, color=ESPRESSO, fontweight='bold')

ax.set_title('Top 5 Products by Total Gross Sales\n(Transactions Dataset)', fontsize=13,
             fontweight='bold', color=ESPRESSO, pad=12)
ax.set_xlabel('Total Gross Sales (₱)', fontsize=11, color=MOCHA)
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'₱{x:,.0f}'))
ax.grid(True, axis='x', linestyle='--', alpha=0.4, color=MOCHA)
ax.tick_params(colors=ESPRESSO)
plt.tight_layout()
plt.savefig('eda_top5_bar.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Saved eda_top5_bar.png")

# Chart 3 — Gross Sales by Category (top 10)
print("📂 Saving EDA Chart 3: Sales by Category...")
cat_top10 = cat_sales.head(10).sort_values(ascending=True)
fig, ax = plt.subplots(figsize=(10, 6))
ax.set_facecolor(CREAM)
fig.patch.set_facecolor('#FAF0E6')

bar_colors = [WARM_PALETTE[i % len(WARM_PALETTE)] for i in range(len(cat_top10))]
bars = ax.barh(cat_top10.index, cat_top10.values,
               color=bar_colors, edgecolor=ESPRESSO, linewidth=0.5)
for bar, val in zip(bars, cat_top10.values):
    ax.text(bar.get_width() + 100, bar.get_y() + bar.get_height() / 2,
            f'₱{val:,.0f}', va='center', fontsize=9, color=ESPRESSO)

ax.set_title('Gross Sales by Category (Top 10)\nCoffeemotto Coffee Shop', fontsize=13,
             fontweight='bold', color=ESPRESSO, pad=12)
ax.set_xlabel('Total Gross Sales (₱)', fontsize=11, color=MOCHA)
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'₱{x:,.0f}'))
ax.grid(True, axis='x', linestyle='--', alpha=0.4, color=MOCHA)
ax.tick_params(colors=ESPRESSO)
plt.tight_layout()
plt.savefig('eda_category_sales.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Saved eda_category_sales.png")

# Chart 4 — Correlation Heatmap
print("🔥 Saving EDA Chart 4: Correlation Heatmap...")
corr_df = df[FEATURE_COLS + ['gross_sales']].copy()
corr_matrix = corr_df.corr()

fig, ax = plt.subplots(figsize=(10, 8))
fig.patch.set_facecolor('#FAF0E6')
cmap = sns.diverging_palette(20, 150, s=80, l=50, as_cmap=True)
mask = np.zeros_like(corr_matrix, dtype=bool)
sns.heatmap(corr_matrix, ax=ax, cmap=cmap, mask=mask, center=0,
            annot=True, fmt='.2f', linewidths=0.5,
            annot_kws={'size': 9}, square=True, cbar_kws={'shrink': 0.8})
ax.set_title('Correlation Matrix — Numeric Features + Gross Sales\nCoffeemotto Dataset',
             fontsize=13, fontweight='bold', color=ESPRESSO, pad=12)
ax.tick_params(colors=ESPRESSO, labelsize=9)
plt.tight_layout()
plt.savefig('eda_correlation_heatmap.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✓ Saved eda_correlation_heatmap.png")


# --- SECTION 4: MODEL TRAINING ---
print("\n" + "=" * 65)
print("[4] Model Training")
print("=" * 65)

lr_model  = LinearRegression()
dt_model  = DecisionTreeRegressor(random_state=42)
rf_model  = RandomForestRegressor(random_state=42)

lr_model.fit(X_train, y_train)
dt_model.fit(X_train, y_train)
rf_model.fit(X_train, y_train)

print("✓ LinearRegression trained.")
print("✓ DecisionTreeRegressor trained.")
print("✓ RandomForestRegressor trained.")


# --- SECTION 5: MODEL EVALUATION ---
print("\n" + "=" * 65)
print("[5] Model Evaluation")
print("=" * 65)

results = {}

def evaluate_model(name, model, X_tr, X_te, y_tr, y_te):
    y_pred = model.predict(X_te)
    mae  = mean_absolute_error(y_te, y_pred)
    rmse = np.sqrt(mean_squared_error(y_te, y_pred))
    r2   = r2_score(y_te, y_pred)
    cv   = cross_val_score(model, X_tr, y_tr, cv=5, scoring='r2')
    cv_mean = cv.mean()

    print(f"\n  📌 {name}")
    print(f"     MAE  : {mae:.4f}")
    print(f"     RMSE : {rmse:.4f}")
    print(f"     R²   : {r2:.4f}")
    print(f"     CV R²: {cv_mean:.4f} (±{cv.std():.4f})")

    return {'MAE': mae, 'RMSE': rmse, 'R2': r2, 'CV_R2': cv_mean}

results['Linear Regression'] = evaluate_model(
    'Linear Regression', lr_model, X_train, X_test, y_train, y_test)
results['Decision Tree'] = evaluate_model(
    'Decision Tree', dt_model, X_train, X_test, y_train, y_test)
results['Random Forest'] = evaluate_model(
    'Random Forest', rf_model, X_train, X_test, y_train, y_test)


# --- SECTION 6: HYPERPARAMETER TUNING ---
print("\n" + "=" * 65)
print("[6] Hyperparameter Tuning (GridSearchCV)")
print("=" * 65)

# Decision Tree Tuning
print("\n🌳 Decision Tree — GridSearchCV...")
dt_param_grid = {'max_depth': [3, 5, 7, 10, None]}
dt_gs = GridSearchCV(DecisionTreeRegressor(random_state=42),
                     dt_param_grid, cv=5, scoring='r2', n_jobs=-1)
dt_gs.fit(X_train, y_train)
print(f"  Best params : {dt_gs.best_params_}")
print(f"  Best CV R²  : {dt_gs.best_score_:.4f}")
best_dt_model = dt_gs.best_estimator_

# Random Forest Tuning
print("\n🌲 Random Forest — GridSearchCV...")
rf_param_grid = {'n_estimators': [50, 100, 200], 'max_depth': [3, 5, 7, None]}
rf_gs = GridSearchCV(RandomForestRegressor(random_state=42),
                     rf_param_grid, cv=5, scoring='r2', n_jobs=-1)
rf_gs.fit(X_train, y_train)
print(f"  Best params : {rf_gs.best_params_}")
print(f"  Best CV R²  : {rf_gs.best_score_:.4f}")
best_rf_model = rf_gs.best_estimator_

# Ridge & Lasso for Linear Regression
print("\n📏 Ridge Regression — GridSearchCV...")
ridge_param_grid = {'alpha': [0.01, 0.1, 1.0, 10.0]}
ridge_gs = GridSearchCV(Ridge(), ridge_param_grid, cv=5, scoring='r2', n_jobs=-1)
ridge_gs.fit(X_train, y_train)
print(f"  Best params : {ridge_gs.best_params_}")
print(f"  Best CV R²  : {ridge_gs.best_score_:.4f}")

print("\n📏 Lasso Regression — GridSearchCV...")
lasso_param_grid = {'alpha': [0.01, 0.1, 1.0, 10.0]}
lasso_gs = GridSearchCV(Lasso(), lasso_param_grid, cv=5, scoring='r2', n_jobs=-1)
lasso_gs.fit(X_train, y_train)
print(f"  Best params : {lasso_gs.best_params_}")
print(f"  Best CV R²  : {lasso_gs.best_score_:.4f}")

# Use best LR variant (Ridge if better, else plain LR)
if ridge_gs.best_score_ > results['Linear Regression']['CV_R2']:
    best_lr_model = ridge_gs.best_estimator_
    print(f"\n  ✓ Using Ridge (alpha={ridge_gs.best_params_['alpha']}) as best LR model.")
else:
    best_lr_model = lr_model
    print("\n  ✓ Using plain LinearRegression as best LR model.")


# --- SECTION 7: FINAL MODEL COMPARISON ---
print("\n" + "=" * 65)
print("[7] Final Model Comparison Table")
print("=" * 65)

# Re-evaluate tuned models
tuned_results = {}
tuned_results['Linear Regression'] = evaluate_model(
    'Linear Regression (tuned)', best_lr_model, X_train, X_test, y_train, y_test)
tuned_results['Decision Tree'] = evaluate_model(
    'Decision Tree (tuned)', best_dt_model, X_train, X_test, y_train, y_test)
tuned_results['Random Forest'] = evaluate_model(
    'Random Forest (tuned)', best_rf_model, X_train, X_test, y_train, y_test)

print("\n")
print(f"{'Model':<22} | {'MAE':>8} | {'RMSE':>8} | {'R²':>7} | {'CV R²':>7}")
print("-" * 65)
for model_name, r in tuned_results.items():
    print(f"{model_name:<22} | {r['MAE']:>8.2f} | {r['RMSE']:>8.2f} | {r['R2']:>7.3f} | {r['CV_R2']:>7.3f}")

best_model_name = max(tuned_results, key=lambda k: tuned_results[k]['CV_R2'])
print(f"\n✅ CONCLUSION: '{best_model_name}' is the best model — highest CV R² and lowest RMSE.")
print("   Random Forest handles non-linearity, is robust to outliers, and provides")
print("   feature importance for business interpretation.")


# --- SECTION 8: FEATURE IMPORTANCE & INTERPRETATION ---
print("\n" + "=" * 65)
print("[8] Feature Importance & Interpretation")
print("=" * 65)

# Random Forest Feature Importances
importances = best_rf_model.feature_importances_
feat_imp = pd.Series(importances, index=FEATURE_COLS).sort_values(ascending=True)

print("\n🌲 Random Forest Feature Importances:")
for feat, imp in feat_imp.sort_values(ascending=False).items():
    print(f"  {feat:20s}: {imp:.4f}")

# Plot Feature Importance
fig, ax = plt.subplots(figsize=(10, 6))
ax.set_facecolor(CREAM)
fig.patch.set_facecolor('#FAF0E6')
colors_imp = [GREEN if v > 0.10 else MOCHA for v in feat_imp.values]
bars = ax.barh(feat_imp.index, feat_imp.values,
               color=colors_imp, edgecolor=ESPRESSO, linewidth=0.5)
for bar, val in zip(bars, feat_imp.values):
    ax.text(bar.get_width() + 0.002, bar.get_y() + bar.get_height() / 2,
            f'{val:.3f}', va='center', fontsize=10, color=ESPRESSO)
ax.set_title('Random Forest — Feature Importances\nCoffeemotto Sales Prediction Model',
             fontsize=13, fontweight='bold', color=ESPRESSO, pad=12)
ax.set_xlabel('Importance Score', fontsize=11, color=MOCHA)
ax.grid(True, axis='x', linestyle='--', alpha=0.4, color=MOCHA)
ax.tick_params(colors=ESPRESSO)
plt.tight_layout()
plt.savefig('feature_importance.png', dpi=150, bbox_inches='tight')
plt.close()
print("\n  ✓ Saved feature_importance.png")

# Linear Regression Coefficients
print("\n📏 Linear Regression Coefficients:")
coef_series = pd.Series(best_lr_model.coef_, index=FEATURE_COLS)
for feat, coef in coef_series.sort_values(ascending=False).items():
    print(f"  {feat:20s}: {coef:+.4f}")


# --- SECTION 9: SAVE MODELS & SCALER ---
print("\n" + "=" * 65)
print("[9] Saving Models & Scaler")
print("=" * 65)

joblib.dump(best_lr_model, 'linear_regression_model.pkl')
joblib.dump(best_dt_model, 'decision_tree_model.pkl')
joblib.dump(best_rf_model, 'random_forest_model.pkl')
joblib.dump(scaler,        'scaler.pkl')
joblib.dump(le_category,   'label_encoder_category.pkl')
joblib.dump(le_product,    'label_encoder_product.pkl')

print("\n✓ linear_regression_model.pkl saved.")
print("✓ decision_tree_model.pkl saved.")
print("✓ random_forest_model.pkl saved.")
print("✓ scaler.pkl saved.")
print("✓ label_encoder_category.pkl saved.")
print("✓ label_encoder_product.pkl saved.")
print("\nAll models saved successfully.")


# --- SECTION 10: PREDICTION FUNCTION ---
print("\n" + "=" * 65)
print("[10] Prediction Function Demo")
print("=" * 65)

def predict_sales(model, scaler, input_features: dict) -> float:
    """
    Predicts gross_sales for a single transaction.

    Parameters
    ----------
    model          : trained sklearn model (LinearRegression, DecisionTree, or RandomForest)
    scaler         : fitted MinMaxScaler
    input_features : dict with keys:
                     day_num, is_weekend, hour, category_encoded,
                     product_encoded, unit_price, quantity, month, week_of_year

    Returns
    -------
    float — predicted gross_sales in Philippine Peso (₱)
    """
    FEATURE_ORDER = ['day_num', 'is_weekend', 'hour', 'category_encoded',
                     'product_encoded', 'unit_price', 'quantity', 'month', 'week_of_year']

    # Build input array in the correct column order
    row = np.array([[input_features[col] for col in FEATURE_ORDER]], dtype=float)

    # Scale using the same scaler fitted during training
    row_scaled = scaler.transform(row)

    # Predict
    prediction = model.predict(row_scaled)[0]
    return round(float(prediction), 2)


# --- Test prediction with a sample input ---
sample = {
    'day_num':          5,       # Saturday
    'is_weekend':       1,
    'hour':             14,      # 2 PM peak
    'category_encoded': category_mapping.get('Iced', 0),
    'product_encoded':  product_mapping.get('Iced Caramel Macchiato', 0),
    'unit_price':       150.0,
    'quantity':         2,
    'month':            4,       # April
    'week_of_year':     17
}

predicted = predict_sales(best_rf_model, scaler, sample)
print(f"\n🔮 Sample Prediction:")
print(f"   Input: Saturday, 2 PM, Iced Caramel Macchiato × 2 (₱150 each)")
print(f"   Predicted Gross Sales: ₱{predicted:.2f}")

print("\n" + "=" * 65)
print("  ✅ ALL SECTIONS COMPLETE")
print("=" * 65)
