# =============================================================================
# HOW TO RUN:
# 1. First run train.py to generate the .pkl model files:
#       python train.py
# 2. Install dependencies:
#       pip install -r requirements.txt
# 3. Start the API:
#       python app.py
#    OR: uvicorn app:app --reload --host 127.0.0.1 --port 8000
# 4. Open coffeemotto_ml_dashboard.html in your browser
# 5. API docs available at: http://127.0.0.1:8000/docs
# =============================================================================

print("☕ Coffeemotto ML API starting...")
print("📊 Loading models from disk...")

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import joblib
import numpy as np
import pandas as pd
import os

# ---------------------------------------------------------------------------
# App Initialization
# ---------------------------------------------------------------------------
app = FastAPI(
    title="Coffeemotto Sales Prediction API",
    description="Machine Learning API for predicting Coffeemotto Coffee Shop gross sales.",
    version="1.0.0",
    contact={"name": "Rivera, Villanueva, Salario, Francisco", "email": "ipt101@plv.edu.ph"}
)

# CORS: Allow browser-based fetch() from any origin
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Model Loading (on startup)
# ---------------------------------------------------------------------------
MODEL_DIR = os.path.dirname(os.path.abspath(__file__))

try:
    rf_model   = joblib.load(os.path.join(MODEL_DIR, 'random_forest_model.pkl'))
    scaler     = joblib.load(os.path.join(MODEL_DIR, 'scaler.pkl'))
    le_category = joblib.load(os.path.join(MODEL_DIR, 'label_encoder_category.pkl'))
    le_product  = joblib.load(os.path.join(MODEL_DIR, 'label_encoder_product.pkl'))
    print("✅ Random Forest model loaded.")
    print("✅ Scaler loaded.")
    print("✅ Label encoders loaded.")
except FileNotFoundError as e:
    print(f"⚠️  Model file not found: {e}")
    print("    Please run train.py first to generate .pkl model files.")
    rf_model = scaler = le_category = le_product = None

print("🚀 Server running at http://127.0.0.1:8000")
print("📖 API docs at http://127.0.0.1:8000/docs")


# ---------------------------------------------------------------------------
# Pydantic Schemas
# ---------------------------------------------------------------------------
class PredictionInput(BaseModel):
    day_num:    int    # 0=Monday … 6=Sunday
    is_weekend: int    # 0 or 1
    hour:       int    # 8–20
    category:   str    # e.g. "Iced", "Hot drinks", "Pasta"
    unit_price: float  # e.g. 150.0
    quantity:   int    # e.g. 2

class PredictionOutput(BaseModel):
    predicted_gross_sales: float
    model_used:  str
    input_received: dict


# ---------------------------------------------------------------------------
# Full Product Catalog (same as HTML dashboard)
# ---------------------------------------------------------------------------
PRODUCTS = [
    {"sku":"10009","name":"Affogato","category":"Hot drinks","price":180},
    {"sku":"10001","name":"Americano","category":"Hot drinks","price":100},
    {"sku":"10133","name":"Artic Strawberry 16","category":"Milk shakes","price":150},
    {"sku":"10134","name":"Artic Strawberry 22","category":"Milk shakes","price":160},
    {"sku":"10136","name":"Baked mac","category":"Pasta","price":160},
    {"sku":"10162","name":"Bana bread","category":"Breads","price":40},
    {"sku":"10163","name":"Banana b pro","category":"Bread promo","price":100},
    {"sku":"10156","name":"Banana Loaf","category":"Breads","price":120},
    {"sku":"10161","name":"Banana Loaf big","category":"Breads","price":150},
    {"sku":"10168","name":"Banana slice","category":"Breads","price":45},
    {"sku":"10112","name":"Barista Drink","category":"Iced","price":150},
    {"sku":"10075","name":"Black Tea","category":"Hot drinks","price":80},
    {"sku":"10089","name":"Blueberry","category":"Cakes","price":185},
    {"sku":"10129","name":"Blueberry 16","category":"Fruit Tea","price":70},
    {"sku":"10130","name":"Blueberry 22","category":"Fruit Tea","price":80},
    {"sku":"10155","name":"Blueberry Bread","category":"Breads","price":50},
    {"sku":"10154","name":"Bon fire Mocha","category":"Hot drinks","price":150},
    {"sku":"10061","name":"Brownie- peanut","category":"Cookies/brownies","price":90},
    {"sku":"10094","name":"Bread Pro","category":"Bread promo","price":70},
    {"sku":"10160","name":"Brownie-bite","category":"Bread promo","price":150},
    {"sku":"10138","name":"Brownies - fudge","category":"Cookies/brownies","price":65},
    {"sku":"10158","name":"Brownies set","category":"Cookies/brownies","price":150},
    {"sku":"10164","name":"Brownies sundae","category":"Cookies/brownies","price":90},
    {"sku":"10003","name":"Cappucino","category":"Hot drinks","price":135},
    {"sku":"10084","name":"Caramel","category":"Add ons","price":20},
    {"sku":"10006","name":"Caramel Macchiato","category":"Hot drinks","price":140},
    {"sku":"10050","name":"Caramel Poems 16","category":"Coolers/frappe","price":160},
    {"sku":"10051","name":"Caramel Poems 22","category":"Coolers/frappe","price":175},
    {"sku":"10038","name":"Caramel Snow 16","category":"Milk shakes","price":150},
    {"sku":"10039","name":"Caramel Snow 22","category":"Milk shakes","price":160},
    {"sku":"10091","name":"Carbonara","category":"Pasta","price":150},
    {"sku":"10114","name":"Cbuns","category":"Breads","price":50},
    {"sku":"10165","name":"Chicken Pastil","category":"Snacks","price":60},
    {"sku":"10145","name":"Chocalate 16","category":"Milk tea","price":80},
    {"sku":"10144","name":"Chocalate 22","category":"Milk tea","price":90},
    {"sku":"10079","name":"Choco crack","category":"Add ons","price":25},
    {"sku":"10107","name":"Choco Lava","category":"Cakes","price":110},
    {"sku":"10008","name":"Chocolate","category":"Hot drinks","price":140},
    {"sku":"10147","name":"Chocolate 16","category":"Milk tea","price":80},
    {"sku":"10146","name":"Chocolate 22","category":"Milk tea","price":90},
    {"sku":"10055","name":"Chocolate Cake","category":"Cakes","price":150},
    {"sku":"10058","name":"Chocolate Smores","category":"Cookies/brownies","price":80},
    {"sku":"10040","name":"Chocolate Winter 16","category":"Milk shakes","price":160},
    {"sku":"10041","name":"Chocolate Winter 22","category":"Milk shakes","price":170},
    {"sku":"10170","name":"Cinamon","category":"Breads","price":25},
    {"sku":"10106","name":"Cinnamon Twist","category":"Breads","price":60},
    {"sku":"10017","name":"Classic 16","category":"Milk tea","price":80},
    {"sku":"10018","name":"Classic 22","category":"Milk tea","price":90},
    {"sku":"10011","name":"Coke","category":"Bottled","price":25},
    {"sku":"10099","name":"Coke Float","category":"Soda Float","price":80},
    {"sku":"10137","name":"Cookie","category":"Cookies/brownies","price":100},
    {"sku":"10042","name":"Cookies & Cream 16","category":"Milk shakes","price":170},
    {"sku":"10151","name":"Cookies & Cream 16-Tea","category":"Milk tea","price":80},
    {"sku":"10043","name":"Cookies & Cream 22","category":"Milk shakes","price":180},
    {"sku":"10152","name":"Cookies & Cream 22-Tea","category":"Milk tea","price":90},
    {"sku":"10095","name":"Dulce de Leche","category":"Cakes","price":150},
    {"sku":"10000","name":"Espresso","category":"Hot drinks","price":80},
    {"sku":"10167","name":"Espresso choco cake","category":"Cakes","price":165},
    {"sku":"10046","name":"Espresso Motto 16","category":"Coolers/frappe","price":130},
    {"sku":"10047","name":"Espresso Motto 22","category":"Coolers/frappe","price":150},
    {"sku":"10029","name":"Fanta","category":"Bottled","price":25},
    {"sku":"10044","name":"Frozen Matcha 16","category":"Milk shakes","price":150},
    {"sku":"10045","name":"Frozen Matcha 22","category":"Milk shakes","price":160},
    {"sku":"10064","name":"Green Tea","category":"Hot drinks","price":80},
    {"sku":"10062","name":"Ham & Cheese","category":"Breads","price":40},
    {"sku":"10021","name":"Hokaido 16","category":"Milk tea","price":80},
    {"sku":"10022","name":"Hokaido 22","category":"Milk tea","price":90},
    {"sku":"10086","name":"Hot Chocolate","category":"Hot drinks","price":130},
    {"sku":"10110","name":"Ice Americano 22","category":"Iced","price":130},
    {"sku":"10120","name":"Ice Cappuccino 22","category":"Iced","price":160},
    {"sku":"10126","name":"Ice Caramel Mac 22","category":"Iced","price":170},
    {"sku":"10124","name":"Ice Chocolate 22","category":"Iced","price":170},
    {"sku":"10117","name":"Ice Latte 22","category":"Iced","price":160},
    {"sku":"10125","name":"Ice Macha Latte 22","category":"Iced","price":170},
    {"sku":"10121","name":"Ice Mocha 22","category":"Iced","price":180},
    {"sku":"10122","name":"Ice Spanish Latte 22","category":"Iced","price":170},
    {"sku":"10123","name":"Ice White Mocha 22","category":"Iced","price":180},
    {"sku":"10067","name":"Iced Americano","category":"Iced","price":120},
    {"sku":"10069","name":"Iced Cappuccino","category":"Iced","price":145},
    {"sku":"10072","name":"Iced Caramel Macchiato","category":"Iced","price":150},
    {"sku":"10074","name":"Iced Chocolate","category":"Iced","price":150},
    {"sku":"10066","name":"Iced Espresso","category":"Iced","price":90},
    {"sku":"10068","name":"Iced Latte","category":"Iced","price":145},
    {"sku":"10070","name":"Iced Mocha","category":"Iced","price":160},
    {"sku":"10071","name":"Iced Spanish Latte","category":"Iced","price":150},
    {"sku":"10073","name":"Iced White Mocha","category":"Iced","price":160},
    {"sku":"10104","name":"Kangkong","category":"Snacks","price":140},
    {"sku":"10002","name":"Latte","category":"Hot drinks","price":135},
    {"sku":"10032","name":"Lemon 16","category":"Fruit Tea","price":70},
    {"sku":"10033","name":"Lemon 22","category":"Fruit Tea","price":80},
    {"sku":"10034","name":"Lychee 16","category":"Fruit Tea","price":70},
    {"sku":"10035","name":"Lychee 22","category":"Fruit Tea","price":80},
    {"sku":"10127","name":"Macha Latte 16","category":"Iced","price":150},
    {"sku":"10131","name":"Mango 16","category":"Fruit Tea","price":70},
    {"sku":"10132","name":"Mango 22","category":"Fruit Tea","price":80},
    {"sku":"10060","name":"Matcha","category":"Cookies/brownies","price":80},
    {"sku":"10025","name":"Matcha 16","category":"Milk tea","price":80},
    {"sku":"10077","name":"Matcha Latte","category":"Hot drinks","price":140},
    {"sku":"10026","name":"Matcha 22","category":"Milk tea","price":90},
    {"sku":"10004","name":"Mocha","category":"Hot drinks","price":150},
    {"sku":"10052","name":"Mocha Sonnet 16","category":"Coolers/frappe","price":150},
    {"sku":"10053","name":"Mocha Sonnet 22","category":"Coolers/frappe","price":165},
    {"sku":"10078","name":"Muffin","category":"Cookies/brownies","price":90},
    {"sku":"10159","name":"Muffin Promo","category":"Bread promo","price":150},
    {"sku":"10111","name":"Nachos","category":"Snacks","price":80},
    {"sku":"10054","name":"NY Cheesecake","category":"Cakes","price":185},
    {"sku":"10023","name":"Okinawa 16","category":"Milk tea","price":80},
    {"sku":"10024","name":"Okinawa 22","category":"Milk tea","price":90},
    {"sku":"10057","name":"Original chocochip","category":"Cookies/brownies","price":80},
    {"sku":"10102","name":"Pork floss","category":"Breads","price":85},
    {"sku":"10103","name":"Pretzel","category":"Breads","price":40},
    {"sku":"10059","name":"Redvelvet","category":"Cookies/brownies","price":80},
    {"sku":"10056","name":"Redvelvet cake","category":"Cakes","price":150},
    {"sku":"10101","name":"RootBeer Float","category":"Soda Float","price":80},
    {"sku":"10150","name":"Salted Caramel 22","category":"Iced","price":170},
    {"sku":"10148","name":"Salted Carmel","category":"Hot drinks","price":140},
    {"sku":"10149","name":"Salted Carmel 16","category":"Iced","price":150},
    {"sku":"10085","name":"Spag","category":"Pasta","price":150},
    {"sku":"10005","name":"Spanish latte","category":"Hot drinks","price":140},
    {"sku":"10096","name":"Spark-blue","category":"Summer special","price":70},
    {"sku":"10097","name":"Spark-strw","category":"Summer special","price":70},
    {"sku":"10143","name":"Strawberry Macha latte 22","category":"Iced","price":170},
    {"sku":"10030","name":"Strawberry 16","category":"Fruit Tea","price":70},
    {"sku":"10031","name":"Strawberry 22","category":"Fruit Tea","price":80},
    {"sku":"10019","name":"Taro 16","category":"Milk tea","price":80},
    {"sku":"10020","name":"Taro 22","category":"Milk tea","price":90},
    {"sku":"10063","name":"Tuna","category":"Breads","price":40},
    {"sku":"10172","name":"Tuna pesto","category":"Pasta","price":150},
    {"sku":"10141","name":"Ube bun","category":"Breads","price":30},
    {"sku":"10142","name":"Ube bun Promo","category":"Bread promo","price":50},
    {"sku":"10049","name":"Vanilla Quotes 22","category":"Coolers/frappe","price":175},
    {"sku":"10048","name":"Vanilla Quotes 16","category":"Coolers/frappe","price":160},
    {"sku":"10036","name":"Vanilla Snow 16","category":"Milk shakes","price":150},
    {"sku":"10037","name":"Vanilla Snow 22","category":"Milk shakes","price":160},
    {"sku":"10065","name":"Water","category":"Bottled","price":20},
    {"sku":"10007","name":"White Mocha","category":"Hot drinks","price":150},
    {"sku":"10080","name":"White Mug","category":"Merch","price":250},
    {"sku":"10028","name":"Winter 22","category":"Milk tea","price":90},
    {"sku":"10027","name":"Winter 16","category":"Milk tea","price":80},
]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/", tags=["Root"])
async def root():
    """Welcome endpoint — confirms the API is running."""
    return {
        "message": "Coffeemotto ML API is running ☕",
        "version": "1.0",
        "docs": "http://127.0.0.1:8000/docs"
    }


@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint — used by the HTML dashboard to show API status."""
    model_status = "loaded" if rf_model is not None else "not loaded (run train.py)"
    return {
        "status": "ok",
        "model": "Random Forest",
        "model_status": model_status,
        "api": "Coffeemotto Sales Predictor"
    }


@app.post("/predict", response_model=PredictionOutput, tags=["Prediction"])
async def predict(data: PredictionInput):
    """
    Main prediction endpoint.
    Accepts a PredictionInput JSON body and returns the predicted gross_sales.

    The feature order used during training must be maintained:
    [day_num, is_weekend, hour, category_encoded, product_encoded,
     unit_price, quantity, month, week_of_year]
    """
    if rf_model is None or scaler is None:
        raise HTTPException(
            status_code=503,
            detail="Model not loaded. Run train.py first to generate .pkl files."
        )

    # --- Encode category using the trained LabelEncoder ---
    try:
        category_encoded = int(le_category.transform([data.category])[0])
    except ValueError:
        # Unknown category — fall back to 0 (most common default)
        category_encoded = 0

    # --- Defaults for fields not provided in the prediction form ---
    product_encoded = 0    # unknown / default product
    month           = 4    # April — middle of the dataset range
    week_of_year    = 17   # week 17 — mid dataset

    # --- Build feature array in the EXACT training column order ---
    feature_array = np.array([[
        data.day_num,
        data.is_weekend,
        data.hour,
        category_encoded,
        product_encoded,
        data.unit_price,
        data.quantity,
        month,
        week_of_year
    ]], dtype=float)

    # --- Scale using the fitted MinMaxScaler ---
    scaled = scaler.transform(feature_array)

    # --- Run inference ---
    raw_prediction = rf_model.predict(scaled)[0]
    predicted_value = round(float(raw_prediction), 2)

    return PredictionOutput(
        predicted_gross_sales=predicted_value,
        model_used="Random Forest",
        input_received=data.dict()
    )


@app.get("/products", tags=["Products"])
async def get_products():
    """Returns the full Coffeemotto product catalog as JSON."""
    return {"count": len(PRODUCTS), "products": PRODUCTS}


@app.get("/summary", tags=["Summary"])
async def get_summary():
    """Returns key business statistics from the Coffeemotto dataset."""
    return {
        "total_products": 160,
        "top_product": "Iced Caramel Macchiato",
        "top_product_sales": 3360,
        "best_day": "May 4, 2026",
        "best_day_sales": 9500,
        "data_period": "March 6 – May 4, 2026",
        "total_transactions": 1604
    }


# ---------------------------------------------------------------------------
# Entry Point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
