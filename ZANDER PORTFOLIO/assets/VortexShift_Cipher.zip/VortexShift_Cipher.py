#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║                   VortexShift Cipher                         ║
║     Positional Caesar + Rail Fence + Mirror Fold             ║
╚══════════════════════════════════════════════════════════════╝
"""

import os
import sys
import time
import math

# ─────────────────────────────────────────────
#  ANSI COLOR / STYLE CONSTANTS
# ─────────────────────────────────────────────
RESET   = "\033[0m"
BOLD    = "\033[1m"
DIM     = "\033[2m"
ITALIC  = "\033[3m"

# Foreground colors
BLACK   = "\033[30m"
RED     = "\033[91m"
GREEN   = "\033[92m"
YELLOW  = "\033[93m"
BLUE    = "\033[94m"
MAGENTA = "\033[95m"
CYAN    = "\033[96m"
WHITE   = "\033[97m"
GRAY    = "\033[90m"

# Background colors
BG_BLACK  = "\033[40m"
BG_BLUE   = "\033[44m"
BG_CYAN   = "\033[46m"
BG_DARK   = "\033[48;5;235m"
BG_PANEL  = "\033[48;5;17m"

# Extended palette
ORANGE    = "\033[38;5;214m"
TEAL      = "\033[38;5;51m"
VIOLET    = "\033[38;5;135m"
LIME      = "\033[38;5;154m"
PINK      = "\033[38;5;213m"


# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────
def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def slow_print(text, delay=0.012):
    for ch in text:
        print(ch, end='', flush=True)
        time.sleep(delay)
    print()

def box(text, color=CYAN, width=60):
    inner = text.center(width - 4)
    top    = color + "╔" + "═" * (width - 2) + "╗" + RESET
    mid    = color + "║" + RESET + BOLD + inner + RESET + color + "║" + RESET
    bot    = color + "╚" + "═" * (width - 2) + "╝" + RESET
    return f"{top}\n{mid}\n{bot}"

def divider(char="─", color=GRAY, width=62):
    print(color + char * width + RESET)

def label(text, color=TEAL):
    print(f"\n{color}{BOLD}  {text}{RESET}")

def step_header(n, title, color=YELLOW):
    print(f"\n  {color}{BOLD}[ STEP {n} ]{RESET}  {WHITE}{title}{RESET}")
    divider("·", GRAY, 50)


# ─────────────────────────────────────────────
#  BANNER
# ─────────────────────────────────────────────
BANNER = f"""
{VIOLET}{BOLD}
  ██╗   ██╗ ██████╗ ██████╗ ████████╗███████╗██╗  ██╗
  ██║   ██║██╔═══██╗██╔══██╗╚══██╔══╝██╔════╝╚██╗██╔╝
  ██║   ██║██║   ██║██████╔╝   ██║   █████╗   ╚███╔╝ 
  ╚██╗ ██╔╝██║   ██║██╔══██╗   ██║   ██╔══╝   ██╔██╗ 
   ╚████╔╝ ╚██████╔╝██║  ██║   ██║   ███████╗██╔╝ ██╗
    ╚═══╝   ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝{RESET}
{TEAL}{BOLD}
  ███████╗██╗  ██╗██╗███████╗████████╗
  ██╔════╝██║  ██║██║██╔════╝╚══██╔══╝
  ███████╗███████║██║█████╗     ██║   
  ╚════██║██╔══██║██║██╔══╝     ██║   
  ███████║██║  ██║██║██║        ██║   
  ╚══════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝{RESET}

{GRAY}  ┌─────────────────────────────────────────────────────┐
  │  Positional Caesar  ·  Rail Fence  ·  Mirror Fold   │
  │         Positional Caesar · Rail Fence · Mirror       │
  └─────────────────────────────────────────────────────┘{RESET}
"""


# ══════════════════════════════════════════════════════════════
#  LAYER 1 — POSITIONAL CAESAR SHIFT
# ══════════════════════════════════════════════════════════════
def positional_caesar_encrypt(text, key):
    result = []
    for i, ch in enumerate(text):
        if ch.isalpha():
            shift = (key + 2 * i) % 26
            base  = ord('A') if ch.isupper() else ord('a')
            result.append(chr((ord(ch) - base + shift) % 26 + base))
        else:
            result.append(ch)
    return "".join(result)

def positional_caesar_decrypt(text, key):
    result = []
    for i, ch in enumerate(text):
        if ch.isalpha():
            shift = (key + 2 * i) % 26
            base  = ord('A') if ch.isupper() else ord('a')
            result.append(chr((ord(ch) - base - shift) % 26 + base))
        else:
            result.append(ch)
    return "".join(result)


# ══════════════════════════════════════════════════════════════
#  LAYER 2 — RAIL FENCE TRANSPOSITION
# ══════════════════════════════════════════════════════════════
def rail_fence_encrypt(text, rails=3):
    if rails < 2 or rails >= len(text):
        return text

    fence = [[] for _ in range(rails)]
    rail, direction = 0, 1

    for ch in text:
        fence[rail].append(ch)
        if rail == 0:
            direction = 1
        elif rail == rails - 1:
            direction = -1
        rail += direction

    return "".join("".join(r) for r in fence), fence

def rail_fence_decrypt(cipher, rails=3):
    n = len(cipher)
    if rails < 2 or rails >= n:
        return cipher

    # Build pattern
    pattern = []
    rail, direction = 0, 1
    for _ in range(n):
        pattern.append(rail)
        if rail == 0:
            direction = 1
        elif rail == rails - 1:
            direction = -1
        rail += direction

    # Count chars per rail
    counts = [pattern.count(r) for r in range(rails)]
    # Slice cipher into rails
    rails_data = []
    idx = 0
    for c in counts:
        rails_data.append(list(cipher[idx:idx+c]))
        idx += c

    # Reconstruct
    result = []
    pointers = [0] * rails
    for r in pattern:
        result.append(rails_data[r][pointers[r]])
        pointers[r] += 1
    return "".join(result)


# ══════════════════════════════════════════════════════════════
#  LAYER 3 — MIRROR FOLD
# ══════════════════════════════════════════════════════════════
def mirror_fold_encrypt(text, rails=3):
    """Split text by rail-fence pattern, then reverse each rail segment."""
    n = len(text)
    if rails < 2 or rails >= n:
        return text[::-1], [text[::-1]]

    pattern = []
    rail, direction = 0, 1
    for _ in range(n):
        pattern.append(rail)
        if rail == 0:
            direction = 1
        elif rail == rails - 1:
            direction = -1
        rail += direction

    fence = [[] for _ in range(rails)]
    for i, ch in enumerate(text):
        fence[pattern[i]].append(ch)

    # Reverse each rail
    mirrored = [list(reversed(r)) for r in fence]
    return "".join("".join(r) for r in mirrored), mirrored

def mirror_fold_decrypt(cipher, rails=3):
    """Reverse of mirror fold: split back, reverse each segment, re-weave."""
    n = len(cipher)
    if rails < 2 or rails >= n:
        return cipher[::-1]

    pattern = []
    rail, direction = 0, 1
    for _ in range(n):
        pattern.append(rail)
        if rail == 0:
            direction = 1
        elif rail == rails - 1:
            direction = -1
        rail += direction

    counts = [pattern.count(r) for r in range(rails)]
    rails_data = []
    idx = 0
    for c in counts:
        seg = list(cipher[idx:idx+c])
        rails_data.append(list(reversed(seg)))   # un-reverse
        idx += c

    result = []
    pointers = [0] * rails
    for r in pattern:
        result.append(rails_data[r][pointers[r]])
        pointers[r] += 1
    return "".join(result)


# ══════════════════════════════════════════════════════════════
#  FULL VORTEXSHIFT — ENCRYPT + DECRYPT
# ══════════════════════════════════════════════════════════════
def vortexshift_encrypt(plaintext, key, rails=3):
    after_l1 = positional_caesar_encrypt(plaintext, key)
    after_l2_text, fence_data = rail_fence_encrypt(after_l1, rails)
    after_l3_text, mirror_data = mirror_fold_encrypt(after_l2_text, rails)
    return after_l1, after_l2_text, after_l3_text, fence_data, mirror_data

def vortexshift_decrypt(ciphertext, key, rails=3):
    after_u3 = mirror_fold_decrypt(ciphertext, rails)
    after_u2 = rail_fence_decrypt(after_u3, rails)
    after_u1 = positional_caesar_decrypt(after_u2, key)
    return after_u3, after_u2, after_u1


# ══════════════════════════════════════════════════════════════
#  PROCESS DISPLAY — ENCRYPT
# ══════════════════════════════════════════════════════════════
def display_encrypt_process(plaintext, key, rails):
    after_l1, after_l2, after_l3, fence_data, mirror_data = vortexshift_encrypt(plaintext, key, rails)

    print(f"\n{BG_DARK}  {'ENCRYPTION PROCESS':^58}  {RESET}")
    divider("═", CYAN, 62)

    # ── LAYER 1 ──
    step_header(1, "Positional Caesar Shift", ORANGE)
    print(f"    {GRAY}Formula: shift = (key + 2×i) mod 26{RESET}")
    print(f"    {GRAY}Key = {key}{RESET}\n")

    print(f"    {'Pos':<5} {'Char':<6} {'Shift':<8} {'Result':<8}")
    divider("·", GRAY, 40)

    shown = 0
    for i, ch in enumerate(plaintext):
        if not ch.isalpha():
            print(f"    {i:<5} {GRAY}{ch!r:<6}{'—':<8}{'(skip)':<8}{RESET}")
            continue
        shift = (key + 2 * i) % 26
        base  = ord('A') if ch.isupper() else ord('a')
        res   = chr((ord(ch) - base + shift) % 26 + base)
        print(f"    {CYAN}{i:<5}{RESET} {YELLOW}{ch:<6}{RESET}{GREEN}{shift:<8}{RESET}{LIME}{res:<8}{RESET}")
        shown += 1

    print(f"\n    {GRAY}Input :{RESET}  {YELLOW}{BOLD}{plaintext}{RESET}")
    print(f"    {GRAY}Output:{RESET}  {ORANGE}{BOLD}{after_l1}{RESET}")

    # ── LAYER 2 ──
    step_header(2, "Rail Fence Transposition", MAGENTA)
    print(f"    {GRAY}Number of rails: {rails}{RESET}\n")

    # Visual zigzag
    n = len(after_l1)
    grid = [['·'] * n for _ in range(rails)]
    rail, direction = 0, 1
    for i, ch in enumerate(after_l1):
        grid[rail][i] = ch
        if rail == 0:        direction = 1
        elif rail == rails - 1: direction = -1
        rail += direction

    for r_idx, row in enumerate(grid):
        row_str = ""
        for ch in row:
            if ch != '·':
                row_str += f"{YELLOW}{BOLD}{ch}{RESET}"
            else:
                row_str += f"{GRAY}·{RESET}"
        print(f"    Rail {r_idx}: {row_str}")

    print(f"\n    {GRAY}Reading rails left→right:{RESET}")
    for r_idx, rail_d in enumerate(fence_data):
        print(f"    Rail {r_idx}: {MAGENTA}{''.join(rail_d)}{RESET}")

    print(f"\n    {GRAY}Input :{RESET}  {ORANGE}{BOLD}{after_l1}{RESET}")
    print(f"    {GRAY}Output:{RESET}  {PINK}{BOLD}{after_l2}{RESET}")

    # ── LAYER 3 ──
    step_header(3, "Mirror Fold (Reverse Each Rail)", TEAL)
    print(f"    {GRAY}Each rail segment is individually reversed{RESET}\n")

    for r_idx, seg in enumerate(mirror_data):
        print(f"    Rail {r_idx} reversed: {TEAL}{''.join(seg)}{RESET}")

    print(f"\n    {GRAY}Input :{RESET}  {PINK}{BOLD}{after_l2}{RESET}")
    print(f"    {GRAY}Output:{RESET}  {CYAN}{BOLD}{after_l3}{RESET}")

    # ── RESULT ──
    divider("═", CYAN, 62)
    print(f"\n  {GREEN}{BOLD}✔  ENCRYPTED RESULT{RESET}")
    print(f"\n  {GRAY}Plaintext :{RESET}  {YELLOW}{BOLD}{plaintext}{RESET}")
    print(f"  {GRAY}Key       :{RESET}  {ORANGE}{key}{RESET}")
    print(f"  {GRAY}Rails     :{RESET}  {ORANGE}{rails}{RESET}")
    print(f"  {GRAY}Ciphertext:{RESET}  {GREEN}{BOLD}{after_l3}{RESET}")
    divider("═", CYAN, 62)

    return after_l3


# ══════════════════════════════════════════════════════════════
#  PROCESS DISPLAY — DECRYPT
# ══════════════════════════════════════════════════════════════
def display_decrypt_process(ciphertext, key, rails):
    after_u3, after_u2, after_u1 = vortexshift_decrypt(ciphertext, key, rails)

    print(f"\n{BG_DARK}  {'DECRYPTION PROCESS':^58}  {RESET}")
    divider("═", TEAL, 62)

    # ── UN-MIRROR ──
    step_header(1, "Undo Mirror Fold (Re-reverse Each Rail)", TEAL)
    print(f"    {GRAY}Split ciphertext back by rail sizes, then un-reverse each segment{RESET}\n")

    # Rebuild to show the split
    n = len(ciphertext)
    pattern = []
    rail, direction = 0, 1
    for _ in range(n):
        pattern.append(rail)
        if rail == 0:           direction = 1
        elif rail == rails - 1: direction = -1
        rail += direction

    counts = [pattern.count(r) for r in range(rails)]
    idx = 0
    for r_idx, c in enumerate(counts):
        seg_reversed = ciphertext[idx:idx+c]
        seg_restored = seg_reversed[::-1]
        print(f"    Rail {r_idx}  reversed-seg: {CYAN}{seg_reversed}{RESET}  →  un-reversed: {TEAL}{seg_restored}{RESET}")
        idx += c

    print(f"\n    {GRAY}Input :{RESET}  {CYAN}{BOLD}{ciphertext}{RESET}")
    print(f"    {GRAY}Output:{RESET}  {PINK}{BOLD}{after_u3}{RESET}")

    # ── UN-RAIL FENCE ──
    step_header(2, "Undo Rail Fence (Re-weave Zigzag)", MAGENTA)
    print(f"    {GRAY}Re-weave the segments back into zigzag order{RESET}\n")

    print(f"    {GRAY}Interleaved result: {RESET}{MAGENTA}{BOLD}{after_u2}{RESET}")
    print(f"\n    {GRAY}Input :{RESET}  {PINK}{BOLD}{after_u3}{RESET}")
    print(f"    {GRAY}Output:{RESET}  {ORANGE}{BOLD}{after_u2}{RESET}")

    # ── UN-CAESAR ──
    step_header(3, "Undo Positional Caesar Shift", ORANGE)
    print(f"    {GRAY}Formula: original = (char - shift) mod 26{RESET}\n")

    print(f"    {'Pos':<5} {'Char':<6} {'Shift':<8} {'Result':<8}")
    divider("·", GRAY, 40)

    for i, ch in enumerate(after_u2):
        if not ch.isalpha():
            print(f"    {i:<5} {GRAY}{ch!r:<6}{'—':<8}{'(skip)':<8}{RESET}")
            continue
        shift = (key + 2 * i) % 26
        base  = ord('A') if ch.isupper() else ord('a')
        res   = chr((ord(ch) - base - shift) % 26 + base)
        print(f"    {CYAN}{i:<5}{RESET} {YELLOW}{ch:<6}{RESET}{GREEN}{shift:<8}{RESET}{LIME}{res:<8}{RESET}")

    # ── RESULT ──
    divider("═", TEAL, 62)
    print(f"\n  {GREEN}{BOLD}✔  DECRYPTED RESULT{RESET}")
    print(f"\n  {GRAY}Ciphertext:{RESET}  {CYAN}{BOLD}{ciphertext}{RESET}")
    print(f"  {GRAY}Key       :{RESET}  {ORANGE}{key}{RESET}")
    print(f"  {GRAY}Rails     :{RESET}  {ORANGE}{rails}{RESET}")
    print(f"  {GRAY}Plaintext :{RESET}  {GREEN}{BOLD}{after_u1}{RESET}")
    divider("═", TEAL, 62)

    return after_u1


# ══════════════════════════════════════════════════════════════
#  ABOUT / CIPHER EXPLANATION
# ══════════════════════════════════════════════════════════════
def show_about():
    clear()
    print(BANNER)
    divider("═", VIOLET, 62)
    print(f"\n  {VIOLET}{BOLD}ABOUT VORTEXSHIFT CIPHER{RESET}")
    print(f"\n  {WHITE}A 3-layer hybrid cipher combining:{RESET}\n")

    layers = [
        ("Layer 1", "Positional Caesar Shift", ORANGE,
         "Each letter is shifted by (key + 2×position) mod 26.\n"
         "  Unlike plain Caesar, the shift GROWS with each position,\n"
         "  making frequency analysis much harder."),
        ("Layer 2", "Rail Fence Transposition", MAGENTA,
         "Characters are written diagonally across N 'rails'\n"
         "  in a zigzag, then read rail-by-rail. This completely\n"
         "  reorders the character sequence."),
        ("Layer 3", "Mirror Fold", TEAL,
         "Each rail segment from Layer 2 is individually reversed.\n"
         "  Even if an attacker breaks the rail fence, the reversed\n"
         "  segments add another layer of confusion."),
    ]

    for tag, name, color, desc in layers:
        print(f"  {color}{BOLD}  {tag}: {name}{RESET}")
        for line in desc.split("\n"):
            print(f"  {GRAY}  {line}{RESET}")
        print()

    divider("─", GRAY, 62)
    print(f"\n  {YELLOW}{BOLD}ENCRYPTION FORMULA:{RESET}")
    print(f"  {WHITE}  C = Mirror( RailFence( PosShift(P, key), rails ), rails ){RESET}")
    print(f"\n  {YELLOW}{BOLD}DECRYPTION FORMULA:{RESET}")
    print(f"  {WHITE}  P = PosShift⁻¹( RailFence⁻¹( Mirror⁻¹(C, rails), rails ), key ){RESET}")
    divider("═", VIOLET, 62)
    input(f"\n  {GRAY}Press ENTER to go back...{RESET}")


# ══════════════════════════════════════════════════════════════
#  MAIN MENU
# ══════════════════════════════════════════════════════════════
def main_menu():
    clear()
    print(BANNER)
    print(f"  {GRAY}{'─'*58}{RESET}")
    print(f"\n  {CYAN}{BOLD}  [ 1 ]{RESET}  {WHITE}Encrypt a message{RESET}")
    print(f"  {TEAL}{BOLD}  [ 2 ]{RESET}  {WHITE}Decrypt a message{RESET}")
    print(f"  {VIOLET}{BOLD}  [ 3 ]{RESET}  {WHITE}About VortexShift Cipher{RESET}")
    print(f"  {GRAY}{BOLD}  [ 4 ]{RESET}  {GRAY}Exit{RESET}")
    print(f"\n  {GRAY}{'─'*58}{RESET}")
    return input(f"\n  {YELLOW}Choose option: {RESET}").strip()


def get_key():
    while True:
        try:
            k = int(input(f"  {YELLOW}Enter key (integer): {RESET}").strip())
            return k
        except ValueError:
            print(f"  {RED}Key must be an integer. Try again.{RESET}")

def get_rails():
    while True:
        try:
            r = int(input(f"  {YELLOW}Enter number of rails [2-6, default 3]: {RESET}").strip() or "3")
            if 2 <= r <= 6:
                return r
            print(f"  {RED}Rails must be between 2 and 6.{RESET}")
        except ValueError:
            print(f"  {RED}Must be an integer. Try again.{RESET}")


# ══════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════
def main():
    while True:
        choice = main_menu()

        if choice == "1":
            clear()
            print(BANNER)
            print(f"\n  {ORANGE}{BOLD}─── ENCRYPT ────────────────────────────────────{RESET}\n")
            msg   = input(f"  {YELLOW}Enter plaintext message: {RESET}").strip()
            if not msg:
                print(f"  {RED}Message cannot be empty.{RESET}")
                time.sleep(1)
                continue
            key   = get_key()
            rails = get_rails()
            clear()
            print(BANNER)
            display_encrypt_process(msg, key, rails)
            input(f"\n  {GRAY}Press ENTER to return to menu...{RESET}")

        elif choice == "2":
            clear()
            print(BANNER)
            print(f"\n  {TEAL}{BOLD}─── DECRYPT ────────────────────────────────────{RESET}\n")
            msg   = input(f"  {CYAN}Enter ciphertext message: {RESET}").strip()
            if not msg:
                print(f"  {RED}Message cannot be empty.{RESET}")
                time.sleep(1)
                continue
            key   = get_key()
            rails = get_rails()
            clear()
            print(BANNER)
            display_decrypt_process(msg, key, rails)
            input(f"\n  {GRAY}Press ENTER to return to menu...{RESET}")

        elif choice == "3":
            show_about()

        elif choice == "4":
            clear()
            print(f"\n  {VIOLET}{BOLD}Thanks for using VortexShift Cipher!{RESET}\n")
            sys.exit(0)

        else:
            print(f"  {RED}Invalid option. Please choose 1-4.{RESET}")
            time.sleep(1)


if __name__ == "__main__":
    main()
